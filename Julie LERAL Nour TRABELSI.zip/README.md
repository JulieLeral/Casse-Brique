# Julie LE RAL / Nour TRABELSI - CPE - TP4 Casse brique - 09/10/2025

# Règles du jeu : 
1. Déplacez la raquette avec les flèches < et >,
2. Appuyez sur 'Lancer' pour actionner la balle,
3. Faites rebondir la balle pour casser toutes les briques,
4. Chaque brique détruite rapporte 10 points,
5. Vous avez 3 vies. La balle perdue réduit vos vies de 1,
6. Le jeu est terminé quand toutes les vies sont perdues,
7. Vous gagnez si vous cassez toutes les briques.

# Spécificités de notre jeu: 
- Une image a était choisie comme arrivère plan du jeu, 
- Trois vies représenter par des coeurs pour réussir le jeu (à chaque chute vers le bas de l'écran, une vie est perdue),
- Le bouton 'Règles' permet d'afficher les règles du jeu,
- le bouton 'Lancer' permet de démarrer le jeu,
- Le bouton 'Rejouer' permet de recommencer une nouvelle partie (reinitialisation le jeu),
- Le bouton 'Quitter' qui permet de quitter le jeu à tout moment,
- Un système de score permet d'affiche le score (+10 points par bloc),
- Le meilleur score est afficher a la fin de la partie si le score est supérieur au précédent meilleur score,
- Des messages s'affichent après certaines actions comme touché un bloc ou perdre une vie.

# implémentations des structures de données demandées : 
- Liste : utilisation d'une liste pour gérer les briques du jeu,
- Pile : utilisation d'une pile pour gérer le meilleur score,
- File : utilisation d'une file pour gérer les messages à afficher.

# Lien GitHub : https://github.com/JulieLeral/Casse-Brique